// src/pages/Home.jsx
export default function Home() {
    return (
      <div>
        <h2 className="text-2xl font-bold mb-4">Welcome to Ya Balash Dashboard</h2>
        <p className="text-gray-700">Here you can manage your content!</p>
      </div>
    );
  }
  